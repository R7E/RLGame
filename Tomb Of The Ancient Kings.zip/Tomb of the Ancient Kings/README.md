# RLGame v0.1.3
My first attempt at a python game using python 2.7 and libtcodpy 1.5.1

You can download the folder or the .zip and play the executable.

Each level is randomly generated.

Some instructions are printed in the game, but you need to know this:

    arrow keys or number pad will move your guy.
    g - get things
    d - drop things
    i - inventory screen
    c - view your character stats
    alt + Enter - full screen
    mouse over things to see what they are
    < - go down the stairs

There is no end, only death.

Watch out for button mashing, it sometimes makes you skip the level up screen.
